#INITIAL SETUP
#----------------------------------------------------------------
import os
import cv2
from cvzone import HandTrackingModule, overlayPNG
import numpy as np

folderPath ='frames'
mylist = os.listdir(folderPath)
graphic = [cv2.imread(f'{folderPath}/{imPath}') for imPath in mylist]
intro =graphic[0];
kill =graphic[1];
winner =graphic[2];
cam = cv2.VideoCapture(0)
detector = HandTrackingModule.HandDetector(maxHands=1,detectionCon=0.77)
#sets the minimum confidence threshold for the detection


#INITILIZING GAME COMPONENTS

#----------------------------------------------------------------

sqr_img =cv2.imread('sqr(2).png')
mlsa =cv2.imread('mlsa.png')  
cv2.imshow('Squid Game', cv2.resize(intro, (0, 0), fx=0.69, fy=0.69))
cv2.waitKey(1)
#INTRO SCREEN WILL STAY UNTIL Q IS PRESSED
while True:
    cv2.imshow('Squid Game', cv2.resize(intro, (0, 0), fx=0.69, fy=0.69))
    if cv2.waitKey(1) & 0xFF == ord('q'):
        continue
    TIMER_MAX = 45
TIMER = TIMER_MAX
maxMove = 6500000
font = cv2.FONT_HERSHEY_SIMPLEX
cam = cv2.VideoCapture(0)
frameHeight = cam.get(cv2.CAM_PROP_FRAME_HEIGHT)
frameWidth = cam.get(cv2.CAM_PROP_FRAME_WIDTH)
gameOver = False
NotWon =True

#GAME LOGIC UPTO THE TEAMS
#-----------------------------------------------------------------------------------------
while not gameOver:
    
    # if cv2.waitKey(10) & 0xFF == ord('w'):
    #     win = Trueq
    #     break
    # press 'w' to win
    if(cv2.waitKey(10) & 0xFF == ord('w')):
        gameOver = True
        break

        
    # Capture frame-by-frame
    ret, frame = cam.read()

    # Apply cookie cutter mask
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    ret, mask = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)
    mask_inv = cv2.bitwise_not(mask)
    cookie_masked = cv2.bitwise_and(sqr_img, sqr_img, mask=mask_inv)
    cutter_masked = cv2.bitwise_and(mlsa, mlsa, mask=mask)

    # Show cookie cutter game overlay
    cv2.imshow('Squid Game Cookie Cutter', cv2.add(cookie_masked, cutter_masked))

    # Check for motion
    gray_prev = gray.copy()
    ret, gray = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)
    diff = cv2.absdiff(gray_prev, gray)
    contours, _ = cv2.findContours(diff, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if contours:
        print('Motion detected!')
        # Insert code to play sound or show text or perform action

    # Quit on 'q' press
    if cv2.waitKey(1) & 0xFF == ord('q'):
        continue
#LOSS SCREEN
if NotWon:
    for i in range(10):
        cv2.imshow('Squid Game', cv2.resize(kill, (0, 0), fx=0.69, fy=0.69))
   
       #show the loss screen from the kill image read before
    while True:
        cv2.imshow('Squid Game', cv2.resize(kill, (0, 0), fx=0.69, fy=0.69))
        if cv2.waitKey(10) & 0xFF == ord('q'):
            break
else:

    cv2.imshow('Squid Game', cv2.resize(winner, (0, 0), fx=0.69, fy=0.69))
    cv2.waitKey(125)
    

    while True:
        cv2.imshow('Squid Game', cv2.resize(winner, (0, 0), fx=0.69, fy=0.69))
        # cv2.imshow('shit',cv2.resize(graphic[3], (0, 0), fx = 0.5, fy = 0.5))
        if cv2.waitKey(10) & 0xFF == ord('q'):
            break

  




# Release capture and destroy windows
cam.release()
cv2.destroyAllWindows()
